﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace PharmacyManagementSystem.Controllers.Purchase
{
    public class PurchaseIndexController : Controller
    {
        //
        // GET: /PurchaseIndex/

        public ActionResult Index()
        {
            return View();
        }

        public ActionResult PurchaseIndex()
        {
            return View();
        }

    }
}
